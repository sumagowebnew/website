import logo from './logo.svg';
import './App.css';
import Aboutuspage from './Components/Aboutuspage';
import Header from './Components/Header';

function App() {
  return (
    <>
    <Header/>
    <Aboutuspage/>
    </>
  );
}

export default App;
